# Weekly Log — Friday Review

> 15 minutes, every Friday. Honest answers only. If "shipped?" is No two weeks running, trigger the kill switch in PLAN.md §6.

**Template per week:** Theme · Shipped? (Y/N + what) · Catalogued? · Business-case section sharpened · Biggest thing avoided · Next week's one ship

---

## Week 0 — Stand up environment + commit charter
- **Shipped?** 
- **Catalogued?** 
- **Business-case section sharpened:** 
- **Biggest thing avoided this week:** 
- **Next week's one ship:** 

---

## Week 1 — SQL fluency + first agentic data read
- **Shipped?** 
- **Catalogued?** 
- **Business-case section sharpened:** 
- **Biggest thing avoided this week:** 
- **Next week's one ship:** 

---

## Week 2 — Skill architecture leveled up
- **Shipped?** 
- **Catalogued?** 
- **Business-case section sharpened:** 
- **Biggest thing avoided this week:** 
- **Next week's one ship:** 

---

## Week 3 — API/code literacy by necessity
- **Shipped?** 
- **Catalogued?** 
- **Business-case section sharpened:** 
- **Biggest thing avoided this week:** 
- **Next week's one ship:** 

---

## Week 4 — Artifact #1 assembled — DAY 30
- **Shipped?** 
- **Catalogued?** 
- **Business-case section sharpened:** 
- **Biggest thing avoided this week:** 
- **Next week's one ship:** 

---

## Week 5 — The transfer half (#1 v2 + Slack)
- **Shipped?** 
- **Catalogued?** 
- **Business-case section sharpened:** 
- **Biggest thing avoided this week:** 
- **Next week's one ship:** 

---

## Week 6 — Artifact #2 — content-ops pipeline
- **Shipped?** 
- **Catalogued?** 
- **Business-case section sharpened:** 
- **Biggest thing avoided this week:** 
- **Next week's one ship:** 

---

## Week 7 — Evals (Promptfoo pass/fail bars)
- **Shipped?** 
- **Catalogued?** 
- **Business-case section sharpened:** 
- **Biggest thing avoided this week:** 
- **Next week's one ship:** 

---

## Week 8 — Artifact #3 + n8n — DAY 60
- **Shipped?** 
- **Catalogued?** 
- **Business-case section sharpened:** 
- **Biggest thing avoided this week:** 
- **Next week's one ship:** 

---

## Week 9 — Codify the method skill + open POV thread
- **Shipped?** 
- **Catalogued?** 
- **Business-case section sharpened:** 
- **Biggest thing avoided this week:** 
- **Next week's one ship:** 

---

## Week 10 — Artifact #4 against the playbook
- **Shipped?** 
- **Catalogued?** 
- **Business-case section sharpened:** 
- **Biggest thing avoided this week:** 
- **Next week's one ship:** 

---

## Week 11 — Package as proof + business case near-final
- **Shipped?** 
- **Catalogued?** 
- **Business-case section sharpened:** 
- **Biggest thing avoided this week:** 
- **Next week's one ship:** 

---

## Week 12 — Go public at volume — DAY 90
- **Shipped?** 
- **Catalogued?** 
- **Business-case section sharpened:** 
- **Biggest thing avoided this week:** 
- **Next week's one ship:** 

