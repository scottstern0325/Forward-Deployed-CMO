# Proof Catalog

The single index of what's been built. Every shipped artifact gets a row the day it ships — no exceptions. This table becomes the portfolio README and feeds `BUSINESS-CASE.md` §5.

| # | Artifact | Workflow solved | Before → after | Eval bar | Status | Link |
|---|----------|-----------------|----------------|----------|--------|------|
| 1 | Competitive / analyst intelligence agent | | | | not started | |
| 2 | Content-ops pipeline | | | | not started | |
| 3 | Multi-step GTM workflow | | | | not started | |
| 4 | Method-test build | | | | not started | |
| — | fde-delivery-playbook (skill) | the method itself | scales to a team | n/a | stub | skills/fde-delivery-playbook |

**Rule:** if it's not in this table, it didn't ship.
