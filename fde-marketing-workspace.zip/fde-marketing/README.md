# Forward-Deployed CMO — Workspace

**Thesis in one line:** Scott Stern is building, in public, the rarest profile in enterprise SaaS marketing — a future-ready CMO who can personally stand up the agentic marketing system *and* scale the teams that run it.

---

## Architecture (how this workspace is used)

| Surface | Role | What lives here |
|---|---|---|
| **Claude Project** ("Forward-Deployed CMO") | Command center — the spine | Strategy, weekly reviews, business-case sharpening, POV drafting. Load `00_CHARTER.md`, `PLAN.md`, `BUSINESS-CASE.md` as Project knowledge; paste `PROJECT-INSTRUCTIONS.md` as custom instructions. |
| **Cowork** (this folder, on your machine) | Workshop — the accelerator | The actual artifact builds. Optional but recommended for build weeks. |
| **Skills** | Portable method | `scott-stern-brand`, `b2b-saas-copywriter`, `linkedin-executive` (existing) + `skills/fde-delivery-playbook` (Wk9 deliverable) |

Project is load-bearing. Cowork is the force multiplier, not a dependency.

## Structure

```
fde-marketing/
  00_CHARTER.md            ← read before every session
  PLAN.md                  ← the 90-day plan (v2)
  BUSINESS-CASE.md         ← the endgame; sharpen weekly
  PROJECT-INSTRUCTIONS.md  ← paste into the Claude Project
  artifacts/               ← the 4 builds (each ships as a case study)
  skills/fde-delivery-playbook/  ← the Wk9 method skill (stub)
  catalog/CATALOG.md       ← the proof index
  brand/POV-THREAD.md      ← the build-in-public content plan
  log/WEEKLY-LOG.md        ← Friday review record (Wk0–Wk12 pre-stubbed)
```

## Start here (Week 0 — today)

1. Read `00_CHARTER.md`. Commit it.
2. Create a private GitHub repo; drop this folder in.
3. Wire the Core Spine MCPs (see `PLAN.md` §2). Ask Claude to generate the exact config blocks per server.
4. Load one free marketing dataset into SQLite.
5. Create the Claude Project; add the three knowledge files + instructions.
6. Open `BUSINESS-CASE.md` §0 and name your three audience members (due end of Week 1).
7. Calendar is already set — first deep-work block is on it.
