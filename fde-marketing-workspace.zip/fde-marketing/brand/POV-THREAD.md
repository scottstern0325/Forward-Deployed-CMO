# POV Thread — Build-in-Public Plan

> Routes through `linkedin-executive` (strategy, format, scoring) → Supergrow MCP (publishing). Never bypass `scott-stern-brand` for voice. **BlackLine first:** no confidential artifact, customer, or roadmap detail goes public.

---

## The angle

Not "look what I built." The angle is the thesis: **the CMO role is bifurcating, and the future-ready CMO is the one with fingers on the keyboard.** Scott is documenting the construction of that profile in real time — which is itself the proof.

This connects to the Agentic Financial Operations narrative Scott already owns: he markets agentic operations for finance; he is now living the same shift in marketing. That synthesis is the differentiated POV no one else can claim.

## Publishing cadence (deliberately back-loaded)

Build quietly first. Proof before posture.

| Gate | When | What goes public |
|---|---|---|
| **Silent build** | Wks 0–8 | Nothing. Accumulate proof. (Optional: 1 low-key "I'm building something" signal post if natural.) |
| **Open the thread** | Wk 9 | The thesis post: the bifurcating CMO. Establish the POV before showing the work. |
| **Proof drop 1** | Wk 10 | Artifact #1 or #2 as a sanitized case study — problem → built → impact. |
| **Method post** | Wk 11 | The delivery-playbook idea (not the full skill) — the "I can scale this" signal. |
| **Volume** | Wk 12 | The full thread: thesis + portfolio + method + the future-ready-CMO argument. |

## Rules

- Lead with the bold declaration, not a question (Scott's voice pattern).
- Every proof post carries a before/after impact line — never just "I made a thing."
- Tie back to AFO / the office of the CFO where it sharpens the point, not as a tagline.
- Score every post via `linkedin-executive` rubric before it goes to Supergrow.
- The thread's job is not engagement. Its job is to make the business-case audience (see `BUSINESS-CASE.md` §0) see Scott as the future-ready CMO *without him telling them directly*.

## Draft bank
*(Hold post drafts here as the build progresses. Empty until Wk8.)*
