---
name: fde-delivery-playbook
description: >
  Scott Stern's codified forward-deployed delivery method for embedding with an enterprise SaaS
  marketing team, scoping a first deployable win, building the agentic system, hardening it,
  transferring it to the team, and measuring impact. STUB — authored in Week 9 of the
  Forward-Deployed CMO program from the lessons of artifacts #1–#3, then stress-tested on
  artifact #4. This is the program's single most valuable deliverable: the method that turns
  "Scott can build" into "Scott can scale a team that builds."
---

# FDE Delivery Playbook  *(STUB — complete in Week 9)*

> Do not write this from theory. Write it from what artifacts #1–#3 actually taught you.
> A method you have stress-tested on yourself is one you can run in a customer's — or your own org's — office.

## 1. Discovery — the questions that find the real friction
*(The 5–8 questions you'd ask a marketing team in the first 30 minutes to locate the highest-pain, most-automatable workflow. Source from how you actually found the artifact-1 use case.)*

## 2. Scoping the first deployable win
*(How you cut a messy workflow down to one shippable slice that proves value fast. The "halve the scope" discipline from the kill switches.)*

## 3. Build
*(The repeatable build pattern: data in → agent/skill chain → output → trigger layer. MCP selection heuristics.)*

## 4. Harden
*(The eval discipline. What pass/fail bar must exist before it's "deployable." From Wk7 Promptfoo work.)*

## 5. Transfer
*(How a non-technical marketer triggers and trusts the system without you. The single most-skipped FDE step.)*

## 6. Measure
*(The before/after impact statement format. How this rolls into the business case.)*

## 7. Scale
*(How one delivered win becomes a team capability — the actual future-ready-CMO move.)*
