# Competitive / Analyst Intelligence Agent

**Build window:** Wk4 (build) → Wk5 (transfer-harden)
**Status:** not started

## Problem hypothesis
Manual competitive & analyst-coverage research that eats hours and goes stale

## What it automates
*(One paragraph. Be specific about the workflow, not the technology.)*

## How it works
*(MCPs/tools used · the agent/skill chain · the non-technical trigger layer)*

## Eval bar (what "good output" objectively means)
*(Filled by Wk7 — Promptfoo)*

## Impact statement (the proof line)
**Before:** ____ (time / cost / who does it / how reliably)
**After:** ____
**One-sentence claim for the business case:** ____

## Transfer notes
*(How a non-technical marketer triggers and trusts this. The "deployed" half.)*
