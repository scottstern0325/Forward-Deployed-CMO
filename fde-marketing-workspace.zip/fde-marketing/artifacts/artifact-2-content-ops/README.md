# Content-Ops Pipeline

**Build window:** Wk6
**Status:** not started

## Problem hypothesis
Brief → on-brand draft → review → multi-channel repurpose done by hand, inconsistently

## What it automates
*(One paragraph. Be specific about the workflow, not the technology.)*

## How it works
*(MCPs/tools used · the agent/skill chain · the non-technical trigger layer)*

## Eval bar (what "good output" objectively means)
*(Filled by Wk7 — Promptfoo)*

## Impact statement (the proof line)
**Before:** ____ (time / cost / who does it / how reliably)
**After:** ____
**One-sentence claim for the business case:** ____

## Transfer notes
*(How a non-technical marketer triggers and trusts this. The "deployed" half.)*
