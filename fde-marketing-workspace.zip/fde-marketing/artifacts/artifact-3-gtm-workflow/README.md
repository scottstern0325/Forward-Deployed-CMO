# Multi-Step GTM Workflow

**Build window:** Wk8
**Status:** not started

## Problem hypothesis
A multi-handoff GTM motion that no single person can run end-to-end

## What it automates
*(One paragraph. Be specific about the workflow, not the technology.)*

## How it works
*(MCPs/tools used · the agent/skill chain · the non-technical trigger layer)*

## Eval bar (what "good output" objectively means)
*(Filled by Wk7 — Promptfoo)*

## Impact statement (the proof line)
**Before:** ____ (time / cost / who does it / how reliably)
**After:** ____
**One-sentence claim for the business case:** ____

## Transfer notes
*(How a non-technical marketer triggers and trusts this. The "deployed" half.)*
